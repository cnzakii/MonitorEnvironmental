def result(r):
    return r.get()
