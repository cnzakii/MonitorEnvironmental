from celery_tasks.curb import *
from celery_tasks.async_tasks import cel
from celery_tasks.result import result
from celery_tasks import curb
from celery_tasks import async_tasks
from celery_tasks import result


