Folder contents
images

Software/hardware requirements
How to compile source code
How do I run any binary program